CREATE PROCEDURE `Test`(IN `x` INT(11), IN `y` INT(11), OUT `res` INT(11))
  BEGIN
  SET res  = x + y;
END